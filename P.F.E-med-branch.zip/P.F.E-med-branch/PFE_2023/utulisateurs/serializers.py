from rest_framework import serializers
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
User = get_user_model()

#------------register-patient-sr-------#
class PatientSerializer(serializers.ModelSerializer):

    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    phone_number = serializers.CharField(required=True)
    nni = serializers.CharField(required=True)
    
    class Meta:
        model = User
        fields = ['phone_number', 'nni', 'password']
    
    def create(self, validated_data):
        email = f"patient{validated_data['nni']}@vaccination.mr"
        password = validated_data.pop('password')
        user = User.objects.create_user(
            email=email,
            phone_number=validated_data['phone_number'],
            nni=validated_data['nni']
        )
        user.set_password(password)
        user.save()
        return user

