from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(CentreDeVaccination)
admin.site.register(User)
admin.site.register(AdminCenter)
admin.site.register(Moughataa)
admin.site.register(Wilaya)
admin.site.register(Vaccine)
admin.site.register(TypeVaccination)
admin.site.register(Dose)
admin.site.register(HistoriqueStock)
admin.site.register(StockVaccins)
admin.site.register(Profile)
admin.site.register(Patient)
admin.site.register(Vaccination)

